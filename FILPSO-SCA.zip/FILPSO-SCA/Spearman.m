function sp=Spearman(sorted_index_x,sorted_index_y,x,y,N)
if length(find((sorted_index_x==sorted_index_y)==1))==0
    di=sorted_index_x-sorted_index_y;
    sp=1-((6*(sum(di.^2)))/(N*(N*N-1)));
else
    xa=mean(x);ya=mean(y);
    tem_up=sum((x-xa).*(y-ya));
    tem_down=sqrt((sum((x-xa).^2))*(sum((y-ya).^2)));
    sp=tem_up/(tem_down+1e-4);
end
end