function [w,Csoc,Ccog] = fuzzy_logic(N,x,xt,fitness,ft,f_deta,deta1,deta2,deta3,deta_max,individual_index)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
 fei1=-0.0025;
 fei2=0.0025;
%fei1=-1;
%fei2=1;
    for i=1:N
        %deta(i)=pdist([x(i,:);xt(i,:)]);%%��һ����ȷ
        deta(i)=pdist([x(i,:);x(individual_index(1),:)]);
% while deta(i)<0 || deta(i) >deta_max
%             deta(i)=round(rand(1,1)*deta_max);
%         end
        %% ����ͳ��deta �� fei���������
        if isempty(pdist([x(i,:),xt(i,:)]))==0
            fei(i)=((min([fitness(i),f_deta])-min([ft(i),f_deta]))/(abs(f_deta)+1e-4))*(pdist([x(i,:),xt(i,:)])/(deta_max+1e-4));
        else
            fei(i)=0;
        end
%         while fei(i)<-1 || fei(i)>1
%             fei(i)=-1+2*rand();
%         end
        %% �������жϣ�deta_md����deta������;o1,0;1�������иߣ�fei_statue����
        %%===========deta��==================
        if (deta(i)>=0) && (deta(i)<deta1)
            deta_md1(i)=1;
        elseif (deta(i)>=deta1) && (deta(i)<deta2)
            deta_md1(i)=(deta2-deta(i))/(deta2-deta1);
        %elseif (deta(i)>=deta2) && (deta(i)<deta_max)
        else    
            deta_md1(i)=0;
        end
        %%===========deta��==================
        if (deta(i)>=0) && (deta(i)<deta1)
            deta_md2(i)=0;
        elseif (deta(i)>=deta1) && (deta(i)<deta2)
            deta_md2(i)=(deta(i)-deta1)/(deta2-deta1);
        elseif (deta(i)>=deta2) && (deta(i)<deta3)
            deta_md2(i)=(deta3-deta(i))/(deta3-deta2);
        %elseif (deta(i)>=deta3) && (deta(i)<deta_max)
        else    
            deta_md2(i)=0;
        end
        %%===========deta��==================
        if (deta(i)>=0) && (deta(i)<deta2)
            deta_md3(i)=0;
        elseif (deta(i)>=deta2) && (deta(i)<deta3)
            deta_md3(i)=(deta(i)-deta2)/(deta3-deta2);
        %elseif (deta(i)>=deta3) && (deta(i)<deta_max)
        else
            deta_md3(i)=1;
        end
        %%============fei��=====================
        if fei(i)==-1
            fei_md1(i)=1;
        elseif (fei(i)>-1)&&(fei(i)<0)
            fei_md1(i)=-fei(i);
        %elseif (fei(i)>=0)&&(fei(i)<=1)
        else
            fei_md1(i)=0;
        end
        %%============feiһ��===================
        %fei_md2(i)=1-abs(fei(i));
        if (fei(i)>=-1)&&(fei(i)<fei1)
            fei_md2(i)=0;
        elseif (fei(i)>=fei1)&&(fei(i)<0)
            fei_md2(i)=(fei1-fei(i))/fei1;
        elseif (fei(i)>=0)&&(fei(i)<fei2)
            fei_md2(i)=(fei2-fei(i))/fei2;
        %elseif (fei(i)>=fei2)&&(fei(i)<1)
        else
            fei_md2(i)=0;
        end
        %%============fei��=====================
        if (fei(i)>=-1)&&(fei(i)<0)
            fei_md3(i)=0;
        elseif (fei(i)>=0)&&(fei(i)<1)
            fei_md3(i)=fei(i);
        %elseif fei(i)==1
        else
            fei_md3(i)=1;
        end
        %% �����
%         i
%         length(deta_md1)
%         length(deta_md2)
%         length(deta_md3)
        RL(1,:)=[deta_md1(i),deta_md2(i),deta_md3(i)];
        RL(2,:)=[fei_md1(i),fei_md2(i),fei_md3(i)];
        %% fei: better1,unvaried2,worse3
        %% deta:Low1,Medium2,High3
        %% w:��(2,3),(1,2),(1,3)����(2,2),(1,1);��(2,1)
        %% soc:��(2,1),(1,2);��(1,2);��(2,3),(1,1),(1,3)
        %% cog:��(1,3);��(2,2),(2,3),(1,1),(1,2);��(2,3)
        w(i)=((RL(2,3)+RL(1,2)+RL(1,3))*0.3+(RL(2,2)+RL(1,1))*0.5+(RL(2,1))*1)...
            /(RL(2,3)+RL(1,2)+RL(1,3)+RL(2,2)+RL(1,1)+RL(2,1));
        Csoc(i)=((RL(1,3))*0.1+(RL(2,2)+RL(2,3)+RL(1,1)+RL(1,2))*1.5+(RL(2,3))*3)...
            /(RL(1,3)+RL(2,2)+RL(2,3)+RL(1,1)+RL(1,2)+RL(2,3));
        Ccog(i)=((RL(2,1)+RL(1,2))*0.1+(RL(1,2))*1.5+(RL(2,3)+RL(1,1)+RL(1,3))*3)...
            /(RL(2,1)+RL(1,2)+RL(1,2)+RL(2,3)+RL(1,1)+RL(1,3));
        

    end
end

