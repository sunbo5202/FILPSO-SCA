%function [gbest,gbestval,itrn1,itrn2,itrn3]=PSO_sunbo_mix(fhd,D,N,max_nfes,lb,ub,varargin)
%%
%   func_num  ------���Ժ������
%   lb   -----------�Ա����±߽�
%   rb   -----------�Ա����ϱ߽�
%   N    -----------���ӳ�ʼ����
%   D    -----------����ά��
%   c    -----------��Ⱥ����ϵ��
%   maxgen    ------����������
%% ============
% D=30ʱ��Nȡ20����Ч����
% cp,TcrӰ������
%% ==========
clc;
clear all;
format long;
format compact;
global initial_flag
%% ���ݼ�¼��������
%Ŀ�꺯�����
val_2_reach =0;
eval('load input_data/Rand_Seeds.txt');
runs=1;
%%������ʼ��
outcome = [];
N=30;
D=10;
stag=70;
%% Record the best results
for func=1:28
    
    %% �߽�����
    lu=GetLU(func,D);
    lb=lu(1,1);ub=lu(2,1);
    if length(ub)==1
        lb=repmat(lb,1,D);
        ub=repmat(ub,1,D);
    end
    mv=0.2*abs((ub-lb));
    lb=repmat(lb,N,1);
    ub=repmat(ub,N,1);    %��������ٶ�
    lv=repmat(-mv,N,1);   %������С�ٶ�
    uv=-lv;
    %% ===========
    
    max_nfes=D*20000;
    
    %% run num
    for run_id=1:runs
        
        %% �����
        %         start_time=cputime;
        %         seed_ind=(D/10*func*runs+run_id)-runs;
        %         seed_ind=mod(seed_ind,1000)+1;
        %         run_seed=Rand_Seeds(seed_ind);
        %         rng(run_seed,'twister');
        epsilon=[];
        fitness=[];violation=[];x=[];pbest=[];
        pbest_fitness=[];                   %���Ӿֲ����ֵ
        pbest_violation=[];
        gbest_fitness=[];
        gbest_violation=[];
        %% =========
        %% ��ʼ����Ⱥ
        x=(ub-lb).*rand(N,D)+lb;
        initial_flag = 0;
        [fitness,violation]=benchmark_func(x, func);%������Ӧ�Ⱥ�Լ��Υ����
        
        %% Լ��������������
        Tmax=max_nfes/N;
        Tcr=0.5;
        Tc=Tcr*Tmax;%ԭʼΪ0.2
        theta=0.3*N;
        cp=5;%ԭʼΪ5
        Th1=100;
        Th2=2;
        t=1;
        
        %% ���޸�
        individual_index=SAEpsSort(fitness,violation,0);
        fitness_worst=fitness(individual_index(end));
        %% ======
        
        %         for i=1:N
        %             if fitness(i) < val_2_reach
        %                 fitness(i) = 0;
        %             end
        %         end
        nfes=N;
        v=lv+2.*rands(N,D).*uv;                         %�ٶȳ�ʼ��
        
        %% �������Ӿֲ���ȫ�����ֵ
        pbest=x;
        pbest_fitness=fitness;                   %���Ӿֲ����ֵ
        pbest_violation=violation;
        gbest_id=individual_index(1);
        gbest_fitness=pbest_fitness(gbest_id);
        gbest_violation=pbest_violation(gbest_id);      %����ȫ�����ֵ
        gbest=pbest(gbest_id,:);
        gbestrep=repmat(gbest,N,1);
        gbestrepfitness=gbest_fitness;
        gbestrepviolation=gbest_violation;
        bf_trend(1)=gbest_fitness;
        bv_trend(1)=gbest_violation;
        %% �Ľ����Ĳ���
        pbest1=pbest; pbest2=pbest; pbest3=pbest;
        pbest1_fitness=pbest_fitness; pbest3_violation=pbest_violation;
        [~,temg1]=min(fitness); [~,temg3]=min(violation);
        gbest1=x(temg1,:); gbest2=gbest; gbest3=x(temg3,:);
        gbest1_fitness=fitness(temg1); gbest3_violation=violation(temg3);
        
        %% ppso����
        w=0.8*ones(1,N);
        Csoc=2.0*ones(1,N);
        Ccog=2.0*ones(1,N);
        itrn=0;
        spc=0;
        %%ѭ��
        while nfes<=max_nfes
            
            %% �Ľ�һ��������Ӧ����Լ��Υ���ȵ������
            [~,sorted_index_x]=sort(fitness);[~,sorted_index_y]=sort(violation);
            data1=fitness;data2=violation;
            %             data1=mapminmax([fitness,violation]');
            %             data2=data1(2,:);
            %             data1(2,:)=[];
            sp=Spearman(sorted_index_x,sorted_index_y,data1,data2,N);
            sp_trend(itrn+1)=sp;
            %% ��������Ե���cp
            %% ����һ����Ӧ�ȽϺã��ɹ��ʽϲ�
            %             if sp<-1
            %                 sp=-1;
            %             elseif sp>1
            %                 sp=1;
            %             end
            %             cp=cp*-sp;
            %             if cp<-5
            %                 cp=-5;
            %             elseif cp>5
            %                 cp=5;
            %             end
            %% ����������Ӧ���Բ�ɹ��ʺ�
            if sp<=-0.2%0.34
                cp=1;
            elseif sp>-0.2 && sp<=0.2 %-0.34;-0.32
                cp=3;
            else
                cp=5;
            end
            %% ============================
            
            %% Լ��������������
            if t==1
                violation_sorted=sort(violation);
                epsilon0=violation_sorted(ceil(theta));
                epsilon1(t)=epsilon0;
            else
                if epsilon0>Th1
                    violation_sorted=sort(violation);
                    epsilon2(t)=violation_sorted(ceil(theta));
                else
                    epsilon2(t)=epsilon0;
                end
                if (epsilon2(t)>Th2) && (epsilon2(t)<epsilon1(t-1))
                    epsilon1(t)=epsilon2(t);
                else
                    epsilon1(t)=epsilon1(t-1);
                end
            end
            if t<=Tc
                epsilon(t)=epsilon1(t)*((1-(t/Tc))^cp);
            else
                epsilon(t)=0;
            end
            t=t+1;
            %% ==============
            
            
            %% �ٶ�λ�ø���
            xt=x; % ��һ��
            ft=fitness;
            vt=violation;
            
            %aa_elite=Csoc'.*rand(N,D).*(pbest-x)+Ccog'.*rand(N,D).*(gbest-x);
            aa_elite=Ccog'.*rand(N,D).*(pbest-x)+Csoc'.*rand(N,D).*(gbest-x);
            %% ================
            v=w'.*v+aa_elite;
            v=(v>uv).*uv+(v<=uv).*v;
            v=(v<lv).*lv+(v>=lv).*v;
            x=xt+v;
            x=((x>=lb)&(x<=ub)).*x+(x<lb).*(lb+0.25.*(ub-lb).*rand(N,D))+(x>ub).*(ub-0.25.*(ub-lb).*rand(N,D));
            [fitness,violation]=benchmark_func(x, func);
            %             for i=1:N
            %                 if fitness(i) < val_2_reach
            %                     fitness(i) = 0;
            %                 end
            %             end
            individual_index=SAEpsSort(fitness,violation,epsilon(t-1));
            
            %% �Ľ�����IFL���ǵ�Լ��Υ���Ⱥ�Ŀ�꺯����ģ��׼��,�÷������иĽ���������ʱ��������
            current=sum(mapminmax([fitness';violation'],0,1));
            previous=sum(mapminmax([ft';vt'],0,1));
            [~,index]=sort(current);
            f_deta=max(current);
            %% fuzzy logic
            bmin=min(x);
            bmax=max(x);
            deta_max=sqrt(sum((bmax-bmin).^2));
            %             bt=pbest;
            %             deta_max=pdist([max(bt);min(bt)]);
            %f_deta=fitness(individual_index(end));%max(fitness);
            %f_deta=fitness_worst;
            deta1=0.2*deta_max;
            deta2=0.4*deta_max;
            deta3=0.6*deta_max;
            [w,Csoc,Ccog] = fuzzy_logic(N,x,xt,current,previous,f_deta,deta1,deta2,deta3,deta_max,index);
            %[w,Csoc,Ccog] = ori_fuzzy_logic(N,x,xt,current,previous,f_deta,deta1,deta2,deta3,deta_max);
            %[w,Csoc,Ccog] = fuzzy_logic(N,x,xt,fitness,ft,f_deta,deta1,deta2,deta3,deta_max,individual_index);
            %[w,Csoc,Ccog] = ori_fuzzy_logic(N,x,xt,fitness,ft,f_deta,deta1,deta2,deta3,deta_max);
            %% ===================
            
            %% �������ӵľֲ���ȫ�����ֵ
            for i=1:N
                if SAEpsCompar(pbest_fitness(i),pbest_violation(i),fitness(i),violation(i),epsilon(t-1))==2
                    %if SAEpsCompar(pbest_fitness(i),pbest_violation(i),fitness(i),violation(i),epsion_tem)==2
                    pbest_fitness(i)=fitness(i);
                    pbest_violation(i)=violation(i);
                    pbest(i,:)=x(i,:);
                end
                if SAEpsCompar(gbest_fitness,gbest_violation,pbest_fitness(i),pbest_violation(i),epsilon(t-1))==2
                    %if SAEpsCompar(gbest_fitness,gbest_violation,pbest_fitness(i),pbest_violation(i),epsion_tem)==2
                    gbest_fitness=pbest_fitness(i);
                    gbest_violation=pbest_violation(i);
                    gbest=pbest(i,:);
                end
                %% ���¸Ľ����Ĳ���
                if pbest1_fitness(i)>fitness(i)
                    pbest1(i,:)=x(i,:);
                    pbest1_fitness(i)=fitness(i);
                    if gbest1_fitness>fitness(i)
                        gbest1=x(i,:);
                        gbest1_fitness=fitness(i);
                    end
                end
                pbest2(i,:)=pbest(i,:);
                gbest2=gbest;
                if pbest3_violation(i)>violation(i)
                    pbest3(i,:)=x(i,:);
                    pbest3_violation(i)=violation(i);
                    if gbest3_violation>fitness(i)
                        gbest3=x(i,:);
                        gbest3_violation=fitness(i);
                    end
                end
            end
            bf_trend(end+1)=gbest_fitness;
            bv_trend(end+1)=gbest_violation;
            PI=5;%������Pardon interval
            if (itrn>stag) && (bf_trend(end)-bf_trend(end-stag)==0) &&  (length(find(pbest_violation==0))/N==0) && (bv_trend(end)-bv_trend(end-stag)==0)
                pbest_index=SAEpsSort(pbest_fitness,pbest_violation,epsilon(t-1));
                [~,bestv_index]=min(pbest_violation);
                [~,bestf_index]=min(pbest_fitness);
                for i=2:N
                    if mod(i,PI)~=0
                        %x(pbest_index(i),:)=(ub(1,:)-lb(1,:)).*rand(1,D)+lb(1,:);
                        x(pbest_index(i),:)=x(pbest_index(i),:)+0.5*(pbest(bestv_index,:)-pbest(bestf_index,:));
                    end
                end
            end
            
            gbestrep=repmat(gbest,N,1);%update the gbest
            itrn=itrn+1;
            gbestrepfitness=gbest_fitness;
            gbestrepviolation=gbest_violation;
            nfes = nfes + N;
            fitness_cov(func,itrn)=gbest_fitness;
            volation_cov(func,itrn)=gbest_violation;
        end %end while
        stag70(func,run_id)=gbest_fitness;
        stag_Vol70(func,run_id)=gbest_violation;
        count_spc(func,run_id)=spc;
        fprintf('��%d�������%d�ε���Ӧ�ȣ�%d��Լ��Υ���ȣ�%d\n',func,run_id,gbest_fitness,gbest_violation);
    end%end runs
end%end func
 %save('fitness_cov.mat','fitness_cov')
  %save('volation_cov.mat','volation_cov')
%save('stag70.mat','stag70')
  %save('epsilon5.mat','epsilon')