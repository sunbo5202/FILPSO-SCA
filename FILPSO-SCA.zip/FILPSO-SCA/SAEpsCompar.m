function statue=SAEpsCompar(x_fitness,x_violation,y_fitness,y_violation,eps)
%% statue=1,x�ã�����y��
if (x_violation<=eps) && (y_violation<=eps)
    if x_fitness<y_fitness
        statue=1;
    else
        statue=2;
    end
elseif (x_violation<=eps) && (y_violation>eps)
    statue=1;
elseif (x_violation>eps) && (y_violation<=eps)
    statue=2;
else
    if x_violation<y_violation
        statue=1;
    else
        statue=2;
    end
end
end